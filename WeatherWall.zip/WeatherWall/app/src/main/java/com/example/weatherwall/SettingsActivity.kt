package com.example.weatherwall

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var status: TextView

    private fun fmt(slot: Int) = "%02d:%02d".format(prefs.hour(slot), prefs.minute(slot))

    private fun refreshStatus() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        status.text = "Exact alarms: ${if (Scheduler.canExact(this)) "OK" else "NOT granted"}\n" +
            "Display over other apps: ${if (Settings.canDrawOverlays(this)) "OK" else "NOT granted"}\n" +
            "Battery unrestricted: ${if (pm.isIgnoringBatteryOptimizations(packageName)) "OK" else "NOT set"}"
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(v: View) = root.addView(
            v, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        add(TextView(this).apply { text = "Page URL" })
        val urlBox = EditText(this).apply {
            setText(prefs.url)
            hint = "https://example.com/weather"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        add(urlBox)

        add(TextView(this).apply { text = "\nReload times (daily) - tick to enable" })
        for (slot in 0 until Prefs.SLOTS) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val cb = CheckBox(this).apply {
                isChecked = prefs.slotEnabled(slot)
                setOnCheckedChangeListener { _, on -> prefs.setSlotEnabled(slot, on) }
            }
            val btn = Button(this).apply {
                text = "Time ${slot + 1}: ${fmt(slot)}"
                setOnClickListener {
                    TimePickerDialog(this@SettingsActivity, { _, h, m ->
                        prefs.setTime(slot, h, m)
                        text = "Time ${slot + 1}: ${fmt(slot)}"
                    }, prefs.hour(slot), prefs.minute(slot), true).show()
                }
            }
            row.addView(cb)
            row.addView(btn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            add(row)
        }

        val desktop = Switch(this).apply {
            text = "Request desktop site"
            isChecked = prefs.desktop
        }
        add(desktop)

        add(TextView(this).apply { text = "\nScroll after page loads (pixels): -500 = up, +500 = down" })
        val scrollBox = EditText(this).apply {
            setText(prefs.scrollPx.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        add(scrollBox)

        add(Button(this).apply {
            text = "Save & display"
            setOnClickListener {
                var u = urlBox.text.toString().trim()
                if (u.isNotEmpty() && !u.contains("://")) u = "https://$u"
                if (u.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "Enter a URL", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.url = u
                prefs.desktop = desktop.isChecked
                prefs.scrollPx = scrollBox.text.toString().trim().toIntOrNull() ?: 0
                Scheduler.scheduleAll(this@SettingsActivity)
                startActivity(
                    Intent(this@SettingsActivity, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra("reload", true)
                )
                finish()
            }
        })
        add(Button(this).apply {
            text = "Back to display (no changes)"
            setOnClickListener { finish() }
        })

        add(TextView(this).apply { text = "\nPermissions (grant all three):" })
        add(Button(this).apply {
            text = "1. Allow exact alarms"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 31) startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        })
        add(Button(this).apply {
            text = "2. Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        add(Button(this).apply {
            text = "3. Battery: set to Unrestricted"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        status = TextView(this).apply { setPadding(0, pad, 0, pad) }
        add(status)
        refreshStatus()

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
