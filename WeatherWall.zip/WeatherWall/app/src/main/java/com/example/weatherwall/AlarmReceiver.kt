package com.example.weatherwall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager

class AlarmReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, intent: Intent) {
        val slot = intent.getIntExtra("slot", 0)
        val prefs = Prefs(ctx)
        if (prefs.url.isBlank() || !prefs.slotEnabled(slot)) return // stale or disabled alarm

        Scheduler.schedule(ctx, slot) // book tomorrow first, so it never gets lost

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "weatherwall:wake"
        ).acquire(15_000)

        // Bring the viewer to the front (if needed) and do a fresh load
        ctx.startActivity(
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra("reload", true)
        )
    }
}
