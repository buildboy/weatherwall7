package com.example.weatherwall

import android.content.Context

class Prefs(ctx: Context) {
    companion object { const val SLOTS = 4 }

    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var url: String
        get() = sp.getString("url", "") ?: ""
        set(v) = sp.edit().putString("url", v).apply()

    var desktop: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) = sp.edit().putBoolean("desktop", v).apply()

    /** Pixels to scroll after the page finishes loading: -500 (up) to +500 (down). */
    var scrollPx: Int
        get() = sp.getInt("scrollPx", 0)
        set(v) = sp.edit().putInt("scrollPx", v.coerceIn(-500, 500)).apply()

    // Defaults: 06:00, 18:00 (on), 12:00, 22:00 (off)
    private val defH = intArrayOf(6, 18, 12, 22)

    fun hour(slot: Int) = sp.getInt("h$slot", defH[slot])
    fun minute(slot: Int) = sp.getInt("m$slot", 0)
    fun setTime(slot: Int, h: Int, m: Int) =
        sp.edit().putInt("h$slot", h).putInt("m$slot", m).apply()

    fun slotEnabled(slot: Int) = sp.getBoolean("on$slot", slot < 2)
    fun setSlotEnabled(slot: Int, on: Boolean) = sp.edit().putBoolean("on$slot", on).apply()
}
