package com.example.weatherwall

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

/** Full-screen, always-on page viewer. Long-press anywhere to open settings. */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val retry = Runnable { reload() }
    private var defaultUa = ""

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        buildWebView()

        if (prefs.url.isBlank()) openSettings() else reload()
    }

    private fun buildWebView() {
        web = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                setSupportZoom(false)
                setSupportMultipleWindows(true)          // lets us intercept window.open() and block it
                javaScriptCanOpenWindowsAutomatically = false
            }
            defaultUa = settings.userAgentString
            isLongClickable = true
            setOnLongClickListener { openSettings(); true }
            webChromeClient = object : WebChromeClient() {
                // Block new windows / popups opened by window.open() or target=_blank
                override fun onCreateWindow(
                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                ): Boolean = false

                // Silence JavaScript alert / confirm / prompt / "leave page?" dialogs
                override fun onJsAlert(
                    view: WebView?, url: String?, message: String?, result: JsResult?
                ): Boolean { result?.confirm(); return true }

                override fun onJsConfirm(
                    view: WebView?, url: String?, message: String?, result: JsResult?
                ): Boolean { result?.cancel(); return true }

                override fun onJsPrompt(
                    view: WebView?, url: String?, message: String?,
                    defaultValue: String?, result: JsPromptResult?
                ): Boolean { result?.cancel(); return true }

                override fun onJsBeforeUnload(
                    view: WebView?, url: String?, message: String?, result: JsResult?
                ): Boolean { result?.confirm(); return true }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    handler.removeCallbacks(retry)
                    if (url != null && url != "about:blank") {
                        view?.evaluateJavascript(scrollScript(prefs.scrollPx), null)
                    }
                }

                // Offline or server error: try again every minute until it loads
                override fun onReceivedError(
                    view: WebView?, request: WebResourceRequest?, error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        handler.removeCallbacks(retry)
                        handler.postDelayed(retry, 60_000)
                    }
                }

                // WebView process crashed or was reclaimed: rebuild and reload
                override fun onRenderProcessGone(
                    view: WebView?, detail: RenderProcessGoneDetail?
                ): Boolean {
                    handler.post {
                        (web.parent as? android.view.ViewGroup)?.removeView(web)
                        web.destroy()
                        buildWebView()
                        if (prefs.url.isNotBlank()) reload()
                    }
                    return true
                }
            }
        }
        setContentView(web)
    }

    /**
     * After the page's load event (plus a short settle): jump to the #anchor in the URL (if any),
     * then scroll by px (negative = up, positive = down). Runs once per page load.
     */
    private fun scrollScript(px: Int) =
        "(function(){var go=function(){setTimeout(function(){" +
            "if(window.__wwDone)return;window.__wwDone=true;" +
            "try{var h=location.hash;if(h.length>1){var id=decodeURIComponent(h.substring(1));" +
            "var el=document.getElementById(id)||document.getElementsByName(id)[0];" +
            "if(el)el.scrollIntoView({block:'start',behavior:'instant'});}}catch(e){}" +
            "if($px!==0)window.scrollBy({top:$px,left:0,behavior:'instant'});" +
            "},500)};" +
            "if(document.readyState==='complete'){go()}else{window.addEventListener('load',go)}})();"

    /** Fresh load of the URL, bypassing cache. */
    private fun reload() {
        handler.removeCallbacks(retry)
        web.settings.userAgentString = if (prefs.desktop) desktopUa else defaultUa
        web.settings.useWideViewPort = prefs.desktop
        web.settings.loadWithOverviewMode = prefs.desktop
        web.clearCache(true)
        // Blank first so the load is always a full one, even if the URL only differs by #anchor
        web.loadUrl("about:blank")
        handler.postDelayed({ web.loadUrl(prefs.url) }, 400)
    }

    private fun openSettings() = startActivity(Intent(this, SettingsActivity::class.java))

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("reload", false) == true && prefs.url.isNotBlank()) reload()
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    // Prevent accidental exit on a wall display
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
